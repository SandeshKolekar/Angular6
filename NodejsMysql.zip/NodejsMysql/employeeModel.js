const employeeDetails =
{
name :{
    type:String,
    required :true,
    value:"Sandesh"
},
id:1,
Address :"Mumbai"


}

module.exports =employeeDetails;

const express= require('express');
//const dbConnection = require("./db");
var bodyparser= require("body-parser");
var cors = require("cors");
const routeDetails = require("./route");

const app = express();

app.listen('3000',() => {
  console.log("Listening port 3000");
  });

 app.use(cors());
  app.use(bodyparser.urlencoded({ extended: false }));
  app.use(bodyparser.json()); 
  app.use('/api',routeDetails);


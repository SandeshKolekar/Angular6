var express =require('express');
var router = express.Router();
const con = require("./db");
var employeedetails = require('./employeeModel');



router.get('/get',function(req,res,next){
//res.send("Routing is working");

  con.query("SELECT * FROM employeedetails", function (err, result, fields) {
    if (err) throw err;
 
    res.json(result);
  /*console.log('>> results: ', result );
  var string=JSON.stringify(result);
  console.log('>> string: ', string );
  var json =  JSON.parse(string);
  console.log('>> json: ', json);
 // res.send(json);
  return string;*/
});
});


router.post('/post',function(req,res,next){
var values = {id:'5',name:'Akshay',address:'Bihar'}
  con.query("INSERT INTO employeedetails SET ?", values,function (err, result, fields) {
    if (err) throw err;
 
    res.json(result);
    


});


});





module.exports =router;